/* =========================================================
   PAWFAV · 花火 — the festival-night engine
   A see you offline special scene. Vanilla JS, one canvas.
   ---------------------------------------------------------
   Fireworks engine (19 shell types) + real Mixkit samples
   (art/sfx/*.mp3) with synthesised fallbacks, water-glow
   reflections, drifting smoke, sakura petals, a scripted
   4-act show (~4¾ minutes, different every run), Zen mode
   (endless), Free play, konami = MOCHI TORRENT.
   ========================================================= */
(function (w, d) {
  'use strict';

  /* ================= 0 · helpers ================= */
  var $  = function (s, r) { return (r || d).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var rnd = function (a, b) { return a + Math.random() * (b - a); };
  var pick = function (arr) { return arr[(Math.random() * arr.length) | 0]; };
  var TAU = Math.PI * 2;
  var mem = {};
  var store = {
    get: function (k, fb) {
      try { var v = localStorage.getItem(k); if (v !== null) return v; } catch (e) {}
      return k in mem ? mem[k] : fb;
    },
    set: function (k, v) {
      mem[k] = String(v);
      try { localStorage.setItem(k, v); } catch (e) {}
    }
  };
  var reduce = (w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches) || store.get('pg-rm', '0') === '1';
  var isSmall = w.innerWidth < 720;

  /* ================= 1 · audio ================= */
  var SFX_FILES = {
    whistle: 'art/sfx/whistle.mp3', 'whistle-pop': 'art/sfx/whistle-pop.mp3',
    whoosh: 'art/sfx/whoosh.mp3', crackle: 'art/sfx/crackle.mp3', echo: 'art/sfx/echo.mp3',
    'boom-s': 'art/sfx/boom-s.mp3', 'boom-m': 'art/sfx/boom-m.mp3', 'boom-double': 'art/sfx/boom-double.mp3',
    'boom-deep': 'art/sfx/boom-deep.mp3', 'boom-l': 'art/sfx/boom-l.mp3', 'boom-xl': 'art/sfx/boom-xl.mp3',
    'crowd-ooh': 'art/sfx/crowd-ooh.mp3', 'crowd-roar': 'art/sfx/crowd-roar.mp3', 'crowd-applause': 'art/sfx/crowd-applause.mp3'
  };
  /* per-sample normalisation (recordings arrive at wildly different loudness) */
  var SFX_GAIN = {
    'whistle': 0.5, 'whistle-pop': 0.55, 'whoosh': 0.62, 'crackle': 0.42, 'echo': 0.7,
    'boom-s': 0.75, 'boom-m': 0.85, 'boom-double': 0.9, 'boom-deep': 1.15, 'boom-l': 1.0, 'boom-xl': 1.35,
    'crowd-ooh': 0.5, 'crowd-roar': 0.85, 'crowd-applause': 0.8
  };
  var actx = null, master = null, comp = null, SFX = {}, sfxReady = false, sfxFailed = [];
  var muted = store.get('pf-fav-muted', '0') === '1';
  var volume = clamp(parseFloat(store.get('pf-fav-vol', '0.9')) || 0.9, 0, 1);

  function ac() {
    if (!actx) {
      var C = w.AudioContext || w.webkitAudioContext;
      if (!C) return null;
      actx = new C();
      master = actx.createGain(); master.gain.value = muted ? 0 : volume;
      comp = actx.createDynamicsCompressor();
      comp.threshold.value = -14; comp.knee.value = 22; comp.ratio.value = 8;
      comp.attack.value = 0.002; comp.release.value = 0.32;
      master.connect(comp); comp.connect(actx.destination);
    }
    if (actx.state === 'suspended') actx.resume().catch(function () {});
    return actx;
  }

  function synthBoom(delay, pan, vol, deep) {
    var c = ac(); if (!c) return;
    var t = c.currentTime + Math.max(0, delay);
    /* body: low sine drop */
    var o = c.createOscillator(), og = c.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(deep ? 64 : 82, t);
    o.frequency.exponentialRampToValueAtTime(deep ? 34 : 42, t + 1.15);
    og.gain.setValueAtTime(0.0001, t);
    og.gain.exponentialRampToValueAtTime(vol, t + 0.014);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 1.5);
    o.connect(og); og.connect(master); o.start(t); o.stop(t + 1.55);
    /* crack: filtered noise burst */
    var len = Math.floor(c.sampleRate * 0.7), buf = c.createBuffer(1, len, c.sampleRate), ch = buf.getChannelData(0);
    for (var i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.4);
    var noise = c.createBufferSource(); noise.buffer = buf;
    var lp = c.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(deep ? 900 : 1600, t);
    lp.frequency.exponentialRampToValueAtTime(90, t + 0.68);
    var ng = c.createGain(); ng.gain.setValueAtTime(vol * 0.9, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.72);
    var p = c.createStereoPanner ? c.createStereoPanner() : null;
    noise.connect(lp); lp.connect(ng);
    if (p) { p.pan.value = clamp(pan, -1, 1); ng.connect(p); p.connect(master); } else ng.connect(master);
    noise.start(t);
  }
  function synthWhistle(delay, pan, vol) {
    var c = ac(); if (!c) return;
    var t = c.currentTime + Math.max(0, delay);
    var o = c.createOscillator(), g = c.createGain(), bp = c.createBiquadFilter();
    o.type = 'sawtooth'; bp.type = 'bandpass'; bp.Q.value = 9;
    bp.frequency.setValueAtTime(420, t);
    bp.frequency.exponentialRampToValueAtTime(1250, t + 0.85);
    o.frequency.setValueAtTime(210, t);
    o.frequency.exponentialRampToValueAtTime(640, t + 0.85);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol * 0.34, t + 0.1);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
    o.connect(bp); bp.connect(g);
    if (c.createStereoPanner) { var p = c.createStereoPanner(); p.pan.value = clamp(pan, -1, 1); g.connect(p); p.connect(master); }
    else g.connect(master);
    o.start(t); o.stop(t + 1.0);
  }

  function decodeAll(onOne, done) {
    var c = ac(); if (!c) { done(false); return; }
    var names = Object.keys(SFX_FILES), pending = names.length, settled = 0, ok = 0;
    names.forEach(function (name) {
      fetch(SFX_FILES[name]).then(function (r) {
        if (!r.ok) throw new Error('http ' + r.status);
        return r.arrayBuffer();
      }).then(function (buf) { return c.decodeAudioData(buf); }).then(function (decoded) {
        SFX[name] = decoded; ok++;
      }).catch(function () {
        sfxFailed.push(name);
      }).then(function () {
        settled++; if (onOne) onOne(settled, pending);
        if (settled === pending) { sfxReady = ok > 0; done(true); }
      });
    });
  }

  function playSample(name, opt) {
    opt = opt || {};
    var c = ac(); if (!c || !master) return;
    var delay = Math.max(0, opt.delay || 0);
    var pan = clamp(opt.pan || 0, -1, 1);
    var vol = (opt.vol == null ? 1 : opt.vol) * (SFX_GAIN[name] || 0.8) * (muted ? 0 : 1);
    if (vol <= 0.001) return;
    var buf = SFX[name];
    if (!buf) {
      /* graceful fallback */
      if (name.indexOf('boom') === 0) synthBoom(delay, pan, vol * 0.9, name === 'boom-xl' || name === 'boom-deep');
      else if (name === 'whistle' || name === 'whistle-pop' || name === 'whoosh' || name === 'echo') synthWhistle(delay, pan, vol);
      return;
    }
    var t = c.currentTime + delay;
    var src = c.createBufferSource(); src.buffer = buf;
    src.playbackRate.value = opt.rate || rnd(0.94, 1.06);
    var g = c.createGain(); g.gain.value = vol;
    var node = g;
    if (c.createStereoPanner) { var p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); node = p; }
    src.connect(g); node.connect(master);
    src.start(t);
    src.onended = function () { src.disconnect(); g.disconnect(); node !== g && node.disconnect(); };
  }
  function setMuted(v) {
    muted = !!v; store.set('pf-fav-muted', muted ? '1' : '0');
    if (master) master.gain.value = muted ? 0 : volume;
    $$('[data-pf-mute]').forEach(function (b) {
      b.setAttribute('aria-pressed', muted ? 'true' : 'false');
      b.innerHTML = muted ? ICON.muteOff : ICON.muteOn;
    });
  }
  function setVolume(v) {
    volume = clamp(v, 0, 1); store.set('pf-fav-vol', String(volume));
    if (master && !muted) master.gain.value = volume;
  }

  /* ================= 2 · canvas & sprites ================= */
  var canvas = $('#pfFx');
  if (!canvas) return;
  var ctx = canvas.getContext('2d', { alpha: true });
  var bgImg = $('#pfBg');
  var W = 0, H = 0, DPR = 1, waterY = 0, particleScale = 1;
  var stars = [], petalsField = [];

  function sizeCanvas() {
    DPR = clamp(w.devicePixelRatio || 1, 1, isSmall ? 1.6 : 2);
    W = w.innerWidth; H = w.innerHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    waterY = H * 0.56;
    makeSprites();
    seedSky();
  }

  var SPRITES = { glow: [], star: [], blob: null, petal: null, ring: null };
  function hueSprite(h, kind) {
    var c = d.createElement('canvas'); c.width = c.height = 64; var g = c.getContext('2d');
    var grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    if (kind === 'glow') {
      grad.addColorStop(0, 'hsla(' + h + ',100%,96%,1)');
      grad.addColorStop(0.18, 'hsla(' + h + ',100%,76%,.92)');
      grad.addColorStop(0.42, 'hsla(' + h + ',95%,60%,.30)');
      grad.addColorStop(1, 'hsla(' + h + ',90%,55%,0)');
      g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    } else { /* star cross spark */
      g.translate(32, 32);
      var lin = g.createLinearGradient(-30, 0, 30, 0);
      lin.addColorStop(0, 'hsla(' + h + ',100%,85%,0)');
      lin.addColorStop(0.5, 'hsla(' + h + ',100%,92%,1)');
      lin.addColorStop(1, 'hsla(' + h + ',100%,85%,0)');
      g.strokeStyle = lin; g.lineCap = 'round';
      g.lineWidth = 5.4; g.beginPath(); g.moveTo(-26, 0); g.lineTo(26, 0); g.stroke();
      g.lineWidth = 3.6; g.beginPath(); g.moveTo(0, -19); g.lineTo(0, 19); g.stroke();
      g.rotate(Math.PI / 4); g.globalAlpha = .55;
      g.lineWidth = 3.2; g.beginPath(); g.moveTo(-13, 0); g.lineTo(13, 0); g.stroke();
      g.beginPath(); g.moveTo(0, -13); g.lineTo(0, 13); g.stroke();
      g.globalAlpha = 1; g.setTransform(1, 0, 0, 1, 0, 0);
      var cg = g.createRadialGradient(32, 32, 0, 32, 32, 17);
      cg.addColorStop(0, 'hsla(' + h + ',100%,98%,.98)'); cg.addColorStop(1, 'hsla(' + h + ',100%,80%,0)');
      g.fillStyle = cg; g.fillRect(0, 0, 64, 64);
    }
    return c;
  }
  function makeSprites() {
    SPRITES.glow = []; SPRITES.star = [];
    for (var i = 0; i < 24; i++) {
      SPRITES.glow.push(hueSprite(i * 15, 'glow'));
      SPRITES.star.push(hueSprite(i * 15, 'star'));
    }
    var b = d.createElement('canvas'); b.width = b.height = 128;
    var bg = b.getContext('2d');
    var rg = bg.createRadialGradient(64, 64, 4, 64, 64, 64);
    rg.addColorStop(0, 'rgba(196,186,214,.34)'); rg.addColorStop(0.55, 'rgba(150,138,176,.13)'); rg.addColorStop(1, 'rgba(140,130,168,0)');
    bg.fillStyle = rg; bg.fillRect(0, 0, 128, 128);
    SPRITES.blob = b;
    var p = d.createElement('canvas'); p.width = p.height = 48; var pg = p.getContext('2d');
    pg.translate(24, 24); pg.rotate(-0.5);
    var pe = pg.createRadialGradient(-3, -3, 1, 0, 0, 19);
    pe.addColorStop(0, 'rgba(255,214,228,.98)'); pe.addColorStop(0.55, 'rgba(255,158,182,.9)'); pe.addColorStop(1, 'rgba(240,110,150,0)');
    pg.fillStyle = pe;
    pg.beginPath(); pg.ellipse(0, 0, 18, 9.5, 0, 0, TAU); pg.fill();
    pg.beginPath(); pg.ellipse(-8, 0, 8.6, 6.4, 0, 0, TAU); pg.fill();
    pg.setTransform(1, 0, 0, 1, 0, 0);
    SPRITES.petal = p;
    var r = d.createElement('canvas'); r.width = r.height = 96; var rgr = r.getContext('2d');
    rgr.strokeStyle = 'rgba(255,255,255,.9)'; rgr.lineWidth = 10;
    rgr.shadowBlur = 14; rgr.shadowColor = 'rgba(255,255,255,.8)';
    rgr.beginPath(); rgr.arc(48, 48, 36, 0, TAU); rgr.stroke();
    SPRITES.ring = r;
  }
  function spriteFor(hue) { return SPRITES.glow[((Math.round(hue / 15) % 24) + 24) % 24]; }
  function starFor(hue) { return SPRITES.star[((Math.round(hue / 15) % 24) + 24) % 24]; }

  /* hues */
  var HUE = { gold: 46, coral: 352, sakura: 348, lavender: 258, mint: 158, sky: 202, white: 40, ember: 30, pink: 330 };
  var PISTILS = [
    { outer: HUE.coral, inner: HUE.gold },
    { outer: HUE.sky, inner: HUE.white },
    { outer: HUE.lavender, inner: HUE.mint },
    { outer: HUE.sakura, inner: HUE.white },
    { outer: HUE.gold, inner: HUE.white }
  ];

  function seedSky() {
    stars = [];
    var n = isSmall ? 55 : 95;
    for (var i = 0; i < n; i++) stars.push({ x: Math.random(), y: Math.random() * 0.42, r: rnd(0.4, 1.5), p: rnd(0, TAU), s: rnd(0.6, 1.8) });
    petalsField = [];
    for (var j = 0; j < (isSmall ? 12 : 22); j++) petalsField.push(newPetal(true));
  }
  function newPetal(anywhere) {
    return {
      x: Math.random() * W, y: anywhere ? Math.random() * H : -30,
      vx: rnd(-14, 26), vy: rnd(12, 30), rot: rnd(0, TAU), vr: rnd(-1.4, 1.4),
      s: rnd(0.5, 1.35), ph: rnd(0, TAU), sway: rnd(0.4, 1.1)
    };
  }

  /* ================= 3 · particles & shells ================= */
  var shells = [], particles = [], smokes = [], reflections = [], shockwaves = [];
  var sessionShells = 0, lifetime = parseInt(store.get('pf-fav-shells', '0'), 10) || 0;
  var flashA = 0, shakeMag = 0, popBudget = 0;

  var G = 980;             /* gravity for shells        */
  var PG_GRAV = 300;       /* gravity for sparks        */
  var DRAG = 0.988;

  function launchShell(opt) {
    /* opt: {x (0..1 target or undefined random), type, color(hue), size(1), silent} */
    opt = opt || {};
    var size = opt.size || 1;
    var x = opt.x != null ? opt.x : rnd(0.30, 0.70) * W;
    if (opt.xPx != null) x = opt.xPx;
    var apex = opt.apex != null ? opt.apex : rnd(0.10, 0.30) * H;
    var vy = Math.sqrt(2 * G * Math.max(120, H + 30 - apex));
    var pan = (x / W) * 2 - 1;
    var type = opt.type || 'peony';
    var shell = {
      x: x, y: H + 30, vy: -vy, vx: rnd(-14, 14),
      type: type, hue: opt.hue != null ? opt.hue : pick([HUE.gold, HUE.coral, HUE.sakura, HUE.lavender, HUE.sky, HUE.mint]),
      size: size, fuse: vy / G * 0.98, age: 0, pan: pan
    };
    shells.push(shell);
    countedShell();
    var sName = opt.whistle || 'whistle';
    playSample(sName, { delay: 0, pan: pan, vol: opt.silent ? 0 : 0.8, rate: type === 'comet' ? rnd(1.05, 1.2) : undefined });
    return shell;
  }
  function countedShell() {
    sessionShells++; lifetime++;
    if (sessionShells % 25 === 0) store.set('pf-fav-shells', String(lifetime));
    updateShellHud();
  }

  function burst(s) {
    var x = s.x, y = s.y, size = s.size, hue = s.hue;
    flashFor(s.type, size, x, y);
    spawnSmoke(x, y, size);
    addReflection(x, hue, size);
    switch (s.type) {
      case 'peony': ringBurst(x, y, hue, 105 * size, 300, 420, { life: [1.5, 2.2] }); boom('boom-m', s.pan, size); break;
      case 'pistil':
        var pair = PISTILS[(Math.random() * PISTILS.length) | 0];
        ringBurst(x, y, pair.outer, 92 * size, 300, 415, { life: [1.5, 2.1] });
        ringBurst(x, y, pair.inner, 46 * size, 165, 235, { life: [1.1, 1.6], star: true });
        boom('boom-m', s.pan, size * 0.95); break;
      case 'chrys':
        ringBurst(x, y, hue, 118 * size, 290, 435, { life: [2.1, 2.9], trail: true, grav: 330, drag: 0.985 });
        boom(size > 1.5 ? 'boom-l' : 'boom-m', s.pan, size); playSample('crackle', { delay: rnd(0.65, 0.95), pan: s.pan, vol: 0.5, rate: 0.9 }); break;
      case 'kamuro':
        ringBurst(x, y, HUE.gold, 140 * size, 215, 335, { life: [3.1, 4.3], trail: true, grav: 260, drag: 0.982, twinkle: true });
        boom('boom-deep', s.pan, size * 0.95); playSample('crackle', { delay: rnd(0.75, 1.05), pan: s.pan, vol: 0.55, rate: 0.82 }); break;
      case 'brocade':
        ringBurst(x, y, HUE.gold, 85 * size, 265, 375, { life: [2.2, 3.1], trail: true, grav: 295, drag: 0.984 });
        ringBurst(x, y, HUE.white, 40 * size, 145, 210, { life: [1.3, 1.8], star: true });
        boom('boom-l', s.pan, size); playSample('crackle', { delay: rnd(0.7, 1.0), pan: s.pan, vol: 0.65 }); playSample('crackle', { delay: rnd(1.15, 1.45), pan: s.pan * 0.8, vol: 0.4, rate: 1.15 }); break;
      case 'sakura':
        ringBurst(x, y, HUE.sakura, 82 * size, 250, 345, { life: [1.7, 2.4] });
        ringBurst(x, y, HUE.white, 34 * size, 135, 190, { life: [1.2, 1.6], star: true });
        ringPetals(x, y, 26 * size);
        boom('boom-m', s.pan, size); playSample('whistle-pop', { delay: 0.05, pan: s.pan, vol: 0.35 }); break;
      case 'saturn':
        ringBurst(x, y, HUE.sky, 64 * size, 225, 300, { life: [1.7, 2.3] });
        flatRing(x, y, HUE.gold, 125 * size, 330, 0.34);
        boom('boom-m', s.pan, size); playSample('boom-s', { delay: 0.16, pan: s.pan * 0.7, vol: 0.6 }); break;
      case 'crossette':
        crossette(x, y, hue, 62 * size, 265);
        boom('boom-m', s.pan, size); break;
      case 'strobe':
        ringBurst(x, y, HUE.white, 88 * size, 265, 390, { life: [1.8, 2.4], strobe: true, star: true });
        flashA = Math.max(flashA, 0.32 * size);
        boom('boom-double', s.pan, size * 1.05); playSample('crowd-ooh', { delay: 0.32, pan: 0, vol: 0.32 }); break;
      case 'ring':
        flatRing(x, y, pick([HUE.mint, HUE.lavender, HUE.sky]), 118 * size, 355, 1);
        flatRing(x, y, HUE.white, 60 * size, 178, 1);
        boom('boom-s', s.pan, size * 0.9); break;
      case 'kiku':
        spiralBurst(x, y, hue, 128 * size);
        boom('boom-m', s.pan, size); break;
      case 'horsetail':
        horsetail(x, y, size);
        boom('boom-s', s.pan, size * 0.8); playSample('crackle', { delay: 0.55, pan: s.pan, vol: 0.35, rate: 1.1 }); break;
      case 'palm':
        palmBurst(x, y, size);
        boom('boom-double', s.pan, size * 1.05); playSample('whoosh', { delay: 0.2, pan: s.pan, vol: 0.4, rate: 0.86 }); break;
      case 'rain':
        ringBurst(x, y, HUE.gold, 122 * size, 195, 320, { life: [3.0, 3.9], trail: true, grav: 235, drag: 0.981, popper: true });
        boom('boom-deep', s.pan, size * 0.9); break;
      case 'heart':
        heartBurst(x, y, size);
        boom('boom-xl', s.pan, size * 1.15); playSample('crowd-ooh', { delay: 0.3, pan: 0, vol: 0.55 }); break;
      case 'paw':
        pawBurst(x, y, size);
        boom('boom-l', s.pan, size); playSample('crowd-ooh', { delay: 0.28, pan: 0, vol: 0.45 }); break;
      case 'comet':
        cometPop(s);
        boom('boom-s', s.pan, size * 0.7); break;
      default:
        ringBurst(x, y, hue, 100 * size, 280, 400, { life: [1.6, 2.2] });
        boom('boom-m', s.pan, size);
    }
    if (Math.random() < 0.16 + size * 0.05) playSample('crowd-ooh', { delay: rnd(0.3, 0.62), pan: rnd(-0.5, 0.5), vol: 0.22 + size * 0.1 });
  }

  function boom(name, pan, size) {
    var sz = size || 1;
    playSample(name, { delay: 0, pan: pan || 0, vol: clamp(0.34 + sz * 0.56, 0.3, 1.5) });
  }
  function flashFor(type, size, x, y) {
    var f = 0;
    if (type === 'strobe' || type === 'palm' || type === 'heart') f = 0.26 * size;
    else if (size > 1.6) f = 0.3 * size;
    else if (size > 1.15) f = 0.13 * size;
    if (f > 0) flashA = Math.max(flashA, Math.min(0.42, f));
    if (size > 1.7) shakeMag = Math.max(shakeMag, 4.6);
    else if (size > 1.3) shakeMag = Math.max(shakeMag, 2.2);
    if (type === 'heart' || type === 'paw') shockwaves.push({ x: x, y: y, r: 12, max: 340, a: 0.5, hue: type === 'heart' ? HUE.coral : HUE.gold });
  }
  function spawnSmoke(x, y, size) {
    for (var i = 0; i < 4; i++) {
      smokes.push({ x: x + rnd(-30, 30) * size, y: y + rnd(-24, 24) * size, r: rnd(36, 66) * size, grow: rnd(9, 15), a: rnd(0.16, 0.24), vy: rnd(-9, -4), vx: rnd(-3, 6), life: rnd(5.5, 8.5), age: 0 });
    }
    if (smokes.length > 46) smokes.splice(0, smokes.length - 46);
  }
  function addReflection(x, hue, size) {
    reflections.push({ x: x, hue: hue, t: 0, life: rnd(2.3, 3.2), strength: clamp(0.5 + size * 0.4, 0.5, 1.1), w: rnd(130, 225) * size });
    if (reflections.length > 24) reflections.shift();
  }

  function ringBurst(x, y, hue, n, spMin, spMax, opt) {
    opt = opt || {};
    spMin *= 1.16; spMax *= 1.16;
    n = Math.round(n * particleScale);
    var lifeA = opt.life || [1.5, 2.2];
    for (var i = 0; i < n; i++) {
      var ang = Math.random() * TAU;
      var sp = rnd(spMin, spMax);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp,
        life: rnd(lifeA[0], lifeA[1]), age: 0, size: rnd(3.1, 6.4) * (opt.star ? 1.22 : 1),
        hue: hue, drag: opt.drag || DRAG, grav: opt.grav != null ? opt.grav : PG_GRAV,
        trail: !!opt.trail, star: !!opt.star, strobe: !!opt.strobe, twinkle: !!opt.twinkle,
        popper: !!opt.popper, kind: 'spark'
      });
    }
  }
  function flatRing(x, y, hue, n, sp, squash) {
    sp *= 1.14;
    n = Math.round(n * particleScale);
    for (var i = 0; i < n; i++) {
      var ang = (i / n) * TAU + rnd(-0.016, 0.016);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp * squash,
        life: rnd(1.9, 2.6), age: 0, size: rnd(3.0, 5.4), hue: hue,
        drag: 0.99, grav: 96, trail: false, star: false, kind: 'spark'
      });
    }
  }
  function spiralBurst(x, y, hue, n) {
    n = Math.round(n * particleScale);
    /* speeds scale inside the loop */
    for (var i = 0; i < n; i++) {
      var arm = i % 3;
      var t = i / n;
      var ang = arm * (TAU / 3) + t * 4.6;
      var sp = 172 + t * 380 + rnd(-18, 18);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp,
        life: rnd(1.9, 2.7), age: 0, size: rnd(2.6, 5.0), hue: (hue + t * 40) % 360,
        drag: 0.985, grav: 210, trail: true, kind: 'spark'
      });
    }
  }
  function horsetail(x, y, size) {
    var n = Math.round(86 * size * particleScale);
    for (var i = 0; i < n; i++) {
      var ang = Math.PI / 2 + rnd(-0.5, 0.5); /* downward cone (canvas y grows downward) */
      var sp = rnd(70, 220);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * sp * 1.6, vy: Math.abs(Math.sin(ang)) * sp + 40,
        life: rnd(2.3, 3.1), age: 0, size: rnd(2.6, 5.2), hue: HUE.ember,
        drag: 0.975, grav: 300, trail: true, kind: 'spark'
      });
    }
  }
  function palmBurst(x, y, size) {
    /* trunk then crown */
    for (var i = 0; i < 22; i++) {
      particles.push({ x: x + rnd(-6, 6), y: y, vx: rnd(-36, 36), vy: rnd(40, 190), life: rnd(0.7, 1.0), age: 0, size: rnd(3.4, 5.8), hue: HUE.ember, drag: 0.96, grav: 620, trail: true, kind: 'spark' });
    }
    ringBurst(x, y, HUE.ember, 52 * size, 180, 265, { life: [1.4, 2.0] });
    ringBurst(x, y, HUE.gold, 42 * size, 260, 395, { life: [1.7, 2.5], trail: true, grav: 320, drag: 0.985, twinkle: true });
  }
  function crossette(x, y, hue, n, sp) {
    n = Math.round(n * particleScale);
    for (var i = 0; i < n; i++) {
      var ang = Math.random() * TAU, spd = rnd(sp * 0.6, sp);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd,
        life: rnd(1.9, 2.5), age: 0, size: rnd(3.2, 5.2), hue: hue,
        drag: 0.99, grav: 150, crossette: true, xAt: rnd(0.42, 0.52), kind: 'spark'
      });
    }
  }
  function ringPetals(x, y, n) {
    for (var i = 0; i < n; i++) {
      var ang = Math.random() * TAU, sp = rnd(60, 170);
      particles.push({
        x: x, y: y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - 30,
        life: rnd(3.4, 4.8), age: 0, size: rnd(5.5, 9.5), hue: HUE.sakura,
        drag: 0.955, grav: 74, kind: 'petal', rot: rnd(0, TAU), vr: rnd(-2.2, 2.2), ph: rnd(0, TAU)
      });
    }
  }
  function heartBurst(x, y, size) {
    var n = Math.round(120 * size * particleScale);
    var k = 0.011 * size * (Math.min(W, H) / 780 + 0.55);
    for (var i = 0; i < n; i++) {
      var t = (i / n) * TAU;
      var hx = 16 * Math.pow(Math.sin(t), 3);
      var hy = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      var px = x + hx * k * 26, py = y - hy * k * 26;
      var dx = px - x, dy = py - y, dl = Math.max(1, Math.hypot(dx, dy));
      var sp = rnd(55, 110) * size;
      particles.push({
        x: px, y: py, vx: (dx / dl) * sp, vy: (dy / dl) * sp,
        life: rnd(2.2, 3.0), age: 0, size: rnd(3.2, 5.8), hue: i % 3 === 0 ? HUE.sakura : HUE.coral,
        drag: 0.965, grav: 64, star: i % 4 === 0, kind: 'spark'
      });
    }
  }
  function pawBurst(x, y, size) {
    var k = 0.052 * size * (Math.min(W, H) / 760 + 0.6) * 26;
    var pads = [
      { dx: 0, dy: 0.42, rx: 1.05, ry: 0.82, n: 40 },
      { dx: -0.98, dy: -0.34, rx: 0.42, ry: 0.55, n: 17 },
      { dx: -0.34, dy: -0.78, rx: 0.42, ry: 0.55, n: 17 },
      { dx: 0.34, dy: -0.78, rx: 0.42, ry: 0.55, n: 17 },
      { dx: 0.98, dy: -0.34, rx: 0.42, ry: 0.55, n: 17 }
    ];
    var total = 0;
    pads.forEach(function (p) {
      var n = Math.round(p.n * particleScale);
      total += n;
      for (var i = 0; i < n; i++) {
        var ang = Math.random() * TAU, rr = Math.sqrt(Math.random());
        var ex = Math.cos(ang) * rr * p.rx, ey = Math.sin(ang) * rr * p.ry;
        var px = x + (p.dx + ex) * k, py = y + (p.dy + ey) * k;
        var sp = rnd(30, 78) * size;
        particles.push({
          x: px, y: py, vx: (px - x) / k * sp * 0.06 + rnd(-14, 14), vy: (py - y) / k * sp * 0.06 + rnd(-14, 14),
          life: rnd(2.2, 3.1), age: 0, size: rnd(3.4, 5.6), hue: i % 4 === 0 ? HUE.gold : HUE.white,
          drag: 0.965, grav: 58, kind: 'spark'
        });
      }
    });
    playSample('whistle-pop', { delay: 0.1, pan: 0, vol: 0.4 });
  }
  function cometPop(s) {
    /* comet shell just fades into a small golden puff */
    ringBurst(s.x, s.y, HUE.gold, 40, 110, 200, { life: [1.0, 1.6], star: true });
  }
  function mineFountain(x, hue) {
    var n = Math.round(52 * particleScale);
    for (var i = 0; i < n; i++) {
      var ang = -Math.PI / 2 + rnd(-0.34, 0.34);
      var sp = rnd(380, 640);
      particles.push({
        x: x, y: H + 6, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp,
        life: rnd(1.5, 2.3), age: 0, size: rnd(2.6, 5.0), hue: hue != null ? hue : pick([HUE.gold, HUE.mint, HUE.white]),
        drag: 0.988, grav: 520, trail: true, kind: 'spark'
      });
    }
    playSample('whoosh', { delay: 0, pan: (x / W) * 2 - 1, vol: 0.7, rate: rnd(0.78, 0.9) });
    playSample('boom-s', { delay: rnd(0.5, 0.72), pan: (x / W) * 2 - 1, vol: 0.42 });
    countedShell();
  }

  /* ================= 4 · update & render ================= */
  function step(dt) {
    popBudget = 14;
    /* shells */
    for (var i = shells.length - 1; i >= 0; i--) {
      var s = shells[i];
      s.age += dt; s.vy += G * dt; s.y += s.vy * dt; s.x += s.vx * dt;
      s.vx *= 0.998;
      if (s.type === 'comet' && Math.random() < 0.85) {
        particles.push({ x: s.x + rnd(-3, 3), y: s.y + rnd(0, 10), vx: rnd(-18, 18), vy: rnd(30, 80),
          life: rnd(0.5, 0.9), age: 0, size: rnd(2.8, 4.9), hue: HUE.gold, drag: 0.96, grav: 60, kind: 'spark', trail: false, star: Math.random() < 0.3 });
      }
      if (s.age >= s.fuse || s.vy >= -40) {
        burst(s);
        shells.splice(i, 1);
      }
    }
    /* particles */
    for (var j = particles.length - 1; j >= 0; j--) {
      var p = particles[j];
      p.age += dt;
      if (p.age >= p.life) { particles.splice(j, 1); continue; }
      p.vx *= p.drag; p.vy = p.vy * p.drag + p.grav * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.kind === 'petal') {
        p.rot += p.vr * dt; p.x += Math.sin(p.age * 2.1 + p.ph) * 34 * dt;
        p.vy = Math.min(p.vy, 68);
      } else if (p.kind === 'spark') {
        if (p.popper && p.age / p.life > 0.55 && Math.random() < 0.055 && popBudget > 0 && particles.length < 1500) {
          popBudget--;
          for (var k = 0; k < 3; k++) {
            particles.push({ x: p.x, y: p.y, vx: rnd(-70, 70), vy: rnd(-70, 70), life: rnd(0.35, 0.6), age: 0,
              size: rnd(1.4, 2.4), hue: HUE.white, drag: 0.94, grav: 240, kind: 'spark', star: true });
          }
          p.age += 0.09;
        }
        if (p.crossette && p.age / p.life > p.xAt) {
          var cn = 4, chu = p.hue, px = p.x, py = p.y, psp = Math.hypot(p.vx, p.vy);
          if (particles.length < 1500) {
            for (var q = 0; q < cn; q++) {
              var ang = Math.random() * TAU;
              particles.push({ x: px, y: py, vx: Math.cos(ang) * (psp * 0.85 + 30), vy: Math.sin(ang) * (psp * 0.85 + 30),
                life: rnd(0.7, 1.1), age: 0, size: rnd(1.8, 3.0), hue: chu, drag: 0.93, grav: 190, kind: 'spark', star: true });
            }
            popBudget = Math.max(0, popBudget - 1);
            if (popBudget > 0) playSample('crackle', { delay: 0, pan: (px / W) * 2 - 1, vol: 0.16, rate: 1.6 });
          }
          p.crossette = false;
        }
      }
    }
    /* smoke */
    for (var m = smokes.length - 1; m >= 0; m--) {
      var sm = smokes[m];
      sm.age += dt; sm.r += sm.grow * dt; sm.x += sm.vx * dt; sm.y += sm.vy * dt;
      sm.a *= (1 - 0.16 * dt);
      if (sm.age > sm.life) smokes.splice(m, 1);
    }
    /* reflections */
    for (var r = reflections.length - 1; r >= 0; r--) {
      reflections[r].t += dt;
      if (reflections[r].t > reflections[r].life) reflections.splice(r, 1);
    }
    /* shockwaves */
    for (var sw2 = shockwaves.length - 1; sw2 >= 0; sw2--) {
      var wv = shockwaves[sw2];
      wv.r += 460 * dt; wv.a *= (1 - 2.6 * dt);
      if (wv.a < 0.02 || wv.r > wv.max) shockwaves.splice(sw2, 1);
    }
    /* falling field petals */
    for (var t = 0; t < petalsField.length; t++) {
      var ft = petalsField[t];
      ft.x += (ft.vx + Math.sin(ft.y * 0.012 + ft.ph) * 22 * ft.sway) * dt;
      ft.y += ft.vy * dt; ft.rot += ft.vr * dt;
      if (ft.y > H + 26 || ft.x < -40 || ft.x > W + 40) petalsField[t] = newPetal(false);
    }
    /* decay flashes */
    flashA = Math.max(0, flashA - 1.9 * dt);
    shakeMag = Math.max(0, shakeMag - 7.5 * dt);
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    var t = now() / 1000;

    /* stars twinkle */
    var i, s;
    for (i = 0; i < stars.length; i++) {
      s = stars[i];
      var a = 0.28 + 0.5 * (0.5 + 0.5 * Math.sin(t * s.s + s.p));
      ctx.globalAlpha = a;
      ctx.fillStyle = '#fff6ea';
      ctx.beginPath(); ctx.arc(s.x * W, s.y * H, s.r, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;

    /* water reflection glow-path */
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (i = 0; i < reflections.length; i++) {
      var refl = reflections[i], k = refl.t / refl.life;
      var ra = refl.strength * (1 - k);
      var yTop = waterY, yBot = H * 0.86;
      var hgt = (yBot - yTop) * (0.66 + 0.34 * (1 - k));
      var wob = Math.sin(t * 2.1 + refl.x * 0.02) * 8 + Math.sin(t * 3.7 + refl.x * 0.013) * 5;
      var col = 'hsla(' + refl.hue + ',100%,';
      /* couple zone: Tejas+Pragati occupy the centre silhouette — spill light but skip water streaks */
      var inBody = refl.x > W * 0.26 && refl.x < W * 0.74;
      if (inBody) ra *= 0.42;
      /* soft elliptical glow — transformed circle, zero hard edges */
      var cy = yTop + hgt * 0.44, rx = refl.w * (1 + k * 0.75), ry = hgt * 0.62;
      ctx.save();
      ctx.translate(refl.x + wob * 0.4, cy);
      ctx.scale(1, ry / Math.max(1, rx));
      var grad = ctx.createRadialGradient(0, 0, 2, 0, 0, rx);
      grad.addColorStop(0, col + '76%,' + (ra * 0.66) + ')');
      grad.addColorStop(0.42, col + '58%,' + (ra * 0.34) + ')');
      grad.addColorStop(1, col + '45%,0)');
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(0, 0, rx, 0, TAU); ctx.fill();
      ctx.restore();
      /* a few horizontal ripple streaks (open water only) */
      ctx.globalAlpha = inBody ? 0 : ra * 0.5;
      ctx.fillStyle = col + '80%,1)';
      for (var rl = 0; rl < 3; rl++) {
        var ry = yTop + hgt * (0.25 + rl * 0.24) + Math.sin(t * 2.6 + rl * 1.7 + refl.x) * 3;
        var rw = refl.w * (0.8 - rl * 0.22) * (1 + k * 0.5);
        ctx.fillRect(refl.x - rw / 2 + wob * (rl + 1) * 0.25, ry, rw, 1.6);
      }
      ctx.globalAlpha = 1;
    }
    ctx.restore();

    /* faint water shimmer drifting on the current */
    ctx.globalAlpha = 0.055;
    ctx.fillStyle = '#ffe9d0';
    for (var wb = 0; wb < 2; wb++) {
      var wy = waterY + (H * 0.86 - waterY) * (0.32 + wb * 0.38) + Math.sin(t * 0.62 + wb * 2.13) * 7;
      ctx.fillRect(0, wy, W, 1.5);
    }
    ctx.globalAlpha = 1;

    /* smoke (normal blend, under fireworks) */
    for (i = 0; i < smokes.length; i++) {
      var smk = smokes[i], sa = smk.a * clamp(1 - smk.age / smk.life, 0, 1);
      ctx.globalAlpha = sa;
      ctx.drawImage(SPRITES.blob, smk.x - smk.r, smk.y - smk.r, smk.r * 2, smk.r * 2);
    }
    ctx.globalAlpha = 1;

    /* fireworks (additive) */
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    var mirror = !isSmall && particles.length < 1150;
    for (i = 0; i < particles.length; i++) {
      var p = particles[i];
      var lifeK = 1 - p.age / p.life;
      var tw = p.twinkle ? (Math.sin(t * 21 + p.x * 0.13) > 0.1 ? 1 : 0.16) : 1;
      var a = clamp(lifeK * (p.kind === 'petal' ? 0.95 : 1.15), 0, 1) * tw;
      if (p.strobe) a *= (Math.sin(t * 33 + i * 0.7) > 0.2 ? 1 : 0.12);
      var spr = p.star ? starFor(p.hue) : spriteFor(p.hue);
      var sz = p.size * (p.kind === 'petal' ? 3.3 : 3.6) * (1 + (1 - lifeK) * 0.32);
      ctx.globalAlpha = a;
      if (p.kind === 'petal') {
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.globalAlpha = a * 0.92;
        ctx.drawImage(SPRITES.petal, -sz, -sz * 0.55, sz * 2, sz * 1.1);
        ctx.restore();
      } else {
        ctx.drawImage(spr, p.x - sz / 2, p.y - sz / 2, sz, sz);
        if (p.trail) {
          ctx.strokeStyle = 'hsla(' + p.hue + ',100%,72%,' + (a * 0.55) + ')';
          ctx.lineWidth = p.size * 0.62;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.028, p.y - p.vy * 0.028);
          ctx.stroke();
        }
      }
      /* mirrored shimmer on the river */
      if (mirror && p.y < waterY && p.kind !== 'petal' && a > 0.2) {
        var my = waterY + (waterY - p.y) * 0.45;
        ctx.globalAlpha = a * 0.16;
        ctx.drawImage(spr, p.x - sz / 2, my - sz / 4, sz, sz / 2);
      }
    }
    /* shells in flight */
    for (i = 0; i < shells.length; i++) {
      var sh = shells[i];
      ctx.globalAlpha = 1;
      ctx.drawImage(SPRITES.star[3], sh.x - 13, sh.y - 13, 26, 26);
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = 'rgba(255,214,140,.75)'; ctx.lineWidth = 2.1;
      ctx.beginPath(); ctx.moveTo(sh.x, sh.y); ctx.lineTo(sh.x - sh.vx * 0.06, sh.y - sh.vy * 0.06); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    /* shockwaves */
    for (i = 0; i < shockwaves.length; i++) {
      var w2 = shockwaves[i];
      ctx.globalAlpha = w2.a;
      ctx.strokeStyle = 'hsla(' + w2.hue + ',100%,80%,.9)'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(w2.x, w2.y, w2.r, 0, TAU); ctx.stroke();
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    /* foreground sakura petals drifting (above everything) */
    for (i = 0; i < petalsField.length; i++) {
      var fp = petalsField[i];
      var fs = 13 * fp.s;
      ctx.save(); ctx.translate(fp.x, fp.y); ctx.rotate(fp.rot);
      ctx.globalAlpha = 0.55 + 0.3 * Math.sin(t + fp.ph);
      ctx.drawImage(SPRITES.petal, -fs, -fs * 0.6, fs * 2, fs * 1.2);
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    /* full-screen flash */
    if (flashA > 0.005) {
      ctx.fillStyle = 'rgba(255,246,235,' + flashA.toFixed(3) + ')';
      ctx.fillRect(0, 0, W, H);
    }
  }

  function now() { return performance.now(); }

  /* distant horizon shells — the constant breathing of a far-off show */
  var distantNext = 0;
  function distantTick(t) {
    if (t < distantNext) return;
    distantNext = t + rnd(1900, 3400);
    if (Math.random() < 0.74) {
      if (Math.random() < 0.2) {
        var x1 = rnd(0.08, 0.28) * W, x2 = rnd(0.72, 0.92) * W, ap = rnd(0.05, 0.15) * H;
        launchShell({ xPx: x1, type: pick(['pistil', 'peony', 'chrys']), apex: ap, size: rnd(0.42, 0.62) });
        launchShell({ xPx: x2, type: pick(['pistil', 'peony', 'ring']), apex: ap, size: rnd(0.42, 0.62) });
      } else {
        launchShell({ xPx: rnd(0.06, 0.94) * W, type: pick(['pistil', 'peony', 'chrys', 'kamuro', 'ring', 'kiku']), apex: rnd(0.04, 0.17) * H, size: rnd(0.42, 0.66) });
      }
    }
  }

  /* ================= 5 · the show director ================= */
  var mode = 'intro';           /* intro | show | free | zen | end */
  var director = null;
  var ambientNext = 0;
  var pendingFinale = false;

  var elIntro = $('#pfIntro'), elEnd = $('#pfEnd'), elActJp = $('#pfActJp'), elActEn = $('#pfActEn'),
      elCaption = $('#pfCaption'), elCaptionText = $('#pfCaptionText'), elCaptionSub = $('#pfCaptionSub'),
      elActCard = $('#pfActCard'), elActCardJp = $('#pfActCardJp'), elActCardEn = $('#pfActCardEn'), elActCardLine = $('#pfActCardLine'),
      elShells = $('#pfShellCount'), elSkip = $('#pfSkip'), elToast = $('#pfToast');

  var actNames = {
    1: ['第一幕', 'first spark'],
    2: ['第二幕', 'the thread'],
    3: ['第三幕', 'sakura rain'],
    4: ['終幕', 'pawstorm']
  };
  function setAct(jp, en) {
    if (elActJp) elActJp.textContent = jp;
    if (elActEn) elActEn.textContent = en;
  }
  function caption(text, sub, dur) {
    if (mode === 'zen' || !elCaption) return;
    elCaptionText.textContent = text;
    elCaptionSub.textContent = sub || '';
    elCaption.classList.add('on');
    clearTimeout(caption._t);
    caption._t = setTimeout(function () { elCaption.classList.remove('on'); }, (dur || 4.6) * 1000);
  }
  function actCard(jp, en, line) {
    if (!elActCard) return;
    elActCardJp.textContent = jp; elActCardEn.textContent = en; elActCardLine.textContent = line || '';
    elActCard.classList.remove('on');
    void elActCard.offsetWidth; /* restart animation */
    elActCard.classList.add('on');
  }
  function toast(msg, dur) {
    if (!elToast) return;
    elToast.textContent = msg;
    elToast.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { elToast.classList.remove('on'); }, (dur || 3.4) * 1000);
  }

  function shoot(type, opts) {
    opts = opts || {};
    if (opts.apex == null) opts.apex = rnd(0.09, 0.30) * H;
    return launchShell(Object.assign ? Object.assign({ type: type }, opts) : Object.assign({ type: type }, opts));
  }
  function sizeRand(a, b) { return rnd(a, b); }
  function huePick() { return pick([HUE.gold, HUE.coral, HUE.sakura, HUE.lavender, HUE.sky, HUE.mint, HUE.white]); }

  function buildShow() {
    var ev = [];
    var T = function (t, fn) { ev.push({ t: t, fn: fn }); };
    var W1 = W * 0.32, W2 = W * 0.68, WL = W * 0.17, WR = W * 0.83, WC = W * 0.5;

    /* —— ACT 1 · FIRST SPARK —— */
    T(1.0, function () { actCard('第一幕', 'FIRST SPARK', 'somewhere above the Sumida river, one small shell learns its own name.'); });
    T(1.4, function () { setAct(actNames[1][0], actNames[1][1]); });
    T(2.8, function () { shoot('comet', { x: WC, size: 1.25, apex: H * 0.22 }); });
    T(8.2, function () { shoot('comet', { x: W1, size: 1.0, apex: H * 0.30 }); });
    T(12.6, function () { shoot('comet', { x: W2, size: 1.0, apex: H * 0.30 }); });
    T(15.2, function () { mineFountain(WL, HUE.gold); });
    T(15.7, function () { mineFountain(WR, HUE.gold); });
    T(19.0, function () { shoot('peony', { x: W1, hue: HUE.gold, apex: H * 0.28 }); });
    T(24.5, function () { shoot('peony', { x: W2, hue: HUE.coral, apex: H * 0.26 }); });
    T(30.0, function () { shoot('pistil', { x: WC, apex: H * 0.2, size: 1.3 }); });
    T(22.0, function () { shoot('chrys', { x: W2, hue: HUE.gold, apex: H * 0.28, size: 0.95 }); });
    T(27.0, function () { shoot('ring', { x: WC, apex: H * 0.3, size: 0.8 }); });
    T(37.0, function () { shoot('chrys', { x: W1, hue: HUE.lavender, apex: H * 0.24, size: 1.2 }); });
    T(41.0, function () { shoot('peony', { x: WC, hue: HUE.sakura, apex: H * 0.27, size: 1.0 }); });
    T(47.0, function () { shoot('kamuro', { x: W2, apex: H * 0.29, size: 0.85 }); });
    T(44.0, function () { shoot('chrys', { x: W2, hue: HUE.sky, apex: H * 0.24, size: 1.15 }); });
    T(49.0, function () { shoot('crossette', { x: WC, hue: HUE.gold, apex: H * 0.19, size: 1.3 }); });
    T(55.5, function () { shoot('pistil', { x: W1, apex: H * 0.3, size: 0.85 }); });
    T(56.0, function () { shoot('pistil', { x: W2, apex: H * 0.3, size: 0.85 }); });
    T(58.0, function () { caption('two phones, both face-down. nobody reached for either.', 'act i · first spark'); });

    /* —— ACT 2 · THE THREAD (mirror duets) —— */
    T(66.0, function () { actCard('第二幕', 'THE THREAD', 'his bank on the left, her bank on the right — one sky stitched between them.'); });
    T(66.4, function () { setAct(actNames[2][0], actNames[2][1]); });
    T(74.5, function () { shoot('peony', { x: WC, hue: HUE.white, apex: H * 0.26, size: 0.85 }); });
    T(98.5, function () { shoot('chrys', { x: WC, hue: HUE.gold, apex: H * 0.18, size: 1.05 }); });
    T(118.0, function () { shoot('ring', { x: WC, apex: H * 0.26, size: 0.9 }); });
    var duets = [
      function () { shoot('peony', { x: WL, hue: HUE.gold, apex: H * 0.24 }); shoot('peony', { x: WR, hue: HUE.gold, apex: H * 0.24 }); },
      function () { shoot('pistil', { x: W1, apex: H * 0.21 }); shoot('pistil', { x: W2, apex: H * 0.21 }); },
      function () { shoot('saturn', { x: WL, apex: H * 0.22, size: 1.1 }); shoot('pistil', { x: WR, apex: H * 0.26, size: 1.0 }); },
      function () { shoot('chrys', { x: WL, hue: HUE.coral, apex: H * 0.2, size: 1.2 }); shoot('chrys', { x: WR, hue: HUE.sakura, apex: H * 0.2, size: 1.2 }); },
      function () { shoot('brocade', { x: W1, apex: H * 0.18, size: 1.25 }); shoot('brocade', { x: W2, apex: H * 0.18, size: 1.25 }); },
      function () { shoot('kiku', { x: WC, hue: HUE.mint, apex: H * 0.17, size: 1.35 }); },
      function () { shoot('crossette', { x: WL, hue: HUE.sky, apex: H * 0.2 }); shoot('crossette', { x: WR, hue: HUE.sky, apex: H * 0.2 }); },
      function () { shoot('ring', { x: W1, apex: H * 0.23 }); shoot('ring', { x: W2, apex: H * 0.23 }); }
    ];
    var dt6 = [71.5, 78.5, 85.5, 93, 102, 111, 121, 131.5];
    duets.forEach(function (fn, i) { T(dt6[i], fn); });
    T(143.0, function () { shoot('brocade', { x: WC, apex: H * 0.16, size: 1.7 }); });
    T(150.0, function () { caption('his side… her side… always the same sky.', 'act ii · the thread'); });

    /* —— ACT 3 · SAKURA RAIN —— */
    T(158.0, function () { actCard('第三幕', 'SAKURA RAIN', 'the whole sky, dressed in pink — her favourite hour never ended.'); });
    T(158.4, function () { setAct(actNames[3][0], actNames[3][1]); });
    T(162.0, function () { shoot('sakura', { x: W1, apex: H * 0.22 }); });
    T(166.5, function () { shoot('sakura', { x: W2, apex: H * 0.2 }); });
    T(164.0, function () { shoot('kamuro', { x: WC, apex: H * 0.19, size: 1.15 }); });
    T(171.0, function () { shoot('sakura', { x: WC, apex: H * 0.24, size: 1.35 }); });
    T(174.0, function () { shoot('sakura', { x: W1 - 60, apex: H * 0.31, size: 0.8 }); });
    T(174.5, function () { shoot('sakura', { x: W2 + 60, apex: H * 0.31, size: 0.8 }); });
    T(176.0, function () { shoot('kamuro', { x: WL, apex: H * 0.17, size: 1.25 }); });
    T(180.5, function () { shoot('kamuro', { x: WR, apex: H * 0.17, size: 1.25 }); });
    T(185.5, function () { shoot('ring', { x: WC, apex: H * 0.2, size: 1.2 }); });
    T(190.0, function () { shoot('sakura', { x: W1 + 40, apex: H * 0.28, size: 0.9 }); shoot('sakura', { x: W2 - 40, apex: H * 0.28, size: 0.9 }); });
    T(196.0, function () { shoot('strobe', { x: WC, apex: H * 0.15, size: 1.3 }); });
    T(192.5, function () { shoot('ring', { x: W1, apex: H * 0.22, size: 0.9 }); });
    T(193.0, function () { shoot('ring', { x: W2, apex: H * 0.22, size: 0.9 }); });
    T(203.0, function () { shoot('horsetail', { x: W1, apex: H * 0.3, size: 1.1 }); });
    T(207.0, function () { shoot('horsetail', { x: W2, apex: H * 0.3, size: 1.1 }); });
    T(212.0, function () { caption('spring never really left. it was just waiting for the sky to notice.', 'act iii · sakura rain'); });

    /* —— FINALE · PAWSTORM —— */
    T(224.0, function () { actCard('終幕', 'PAWSTORM', 'for one minute, nobody along this river watches alone.'); });
    T(224.4, function () { setAct(actNames[4][0], actNames[4][1]); });
    var barrageTypes = ['peony', 'pistil', 'chrys', 'saturn', 'kiku', 'ring', 'brocade'];
    var bt = 228.5, stepT = 1.05, side = 0;
    while (bt < 258) {
      (function (t, sd) {
        T(t, function () {
          var x = sd % 2 === 0 ? rnd(WL, W1) : rnd(W2, WR);
          if (sd % 3 === 2) x = WC + rnd(-W * 0.08, W * 0.08);
          shoot(pick(barrageTypes), { x: x, hue: huePick(), apex: rnd(0.1, 0.26) * H, size: sizeRand(0.9, 1.35) });
        });
      })(bt, side);
      bt += stepT; stepT = Math.max(0.62, stepT * 0.9); side++;
    }
    T(259.0, function () { mineFountain(WL, HUE.coral); });
    T(259.4, function () { mineFountain(WR, HUE.coral); });
    T(260.0, function () { mineFountain(WC, HUE.gold); });
    T(263.0, function () { /* THE BIG ONE */
      var big = launchShell({ type: 'brocade', xPx: WC, apex: H * 0.15, size: 2.35, hue: HUE.gold });
      flashA = Math.max(flashA, 0.3);
    });
    T(265.2, function () {
      flashA = Math.max(flashA, 0.42); shakeMag = Math.max(shakeMag, 7);
      playSample('boom-xl', { delay: 0, pan: 0, vol: 1.5 });
      playSample('echo', { delay: 0.14, pan: 0, vol: 0.85 });
      playSample('boom-deep', { delay: 0.02, pan: 0, vol: 1.2 });
      playSample('crowd-roar', { delay: 0.34, pan: 0, vol: 1.0 });
      playSample('crowd-applause', { delay: 1.35, pan: 0, vol: 0.9 });
    });
    T(270.5, function () { shoot('heart', { x: WL + 30, apex: H * 0.2, size: 1.35 }); });
    T(271.1, function () { shoot('paw', { x: WR - 30, apex: H * 0.2, size: 1.3 }); });
    T(275.5, function () { shoot('kamuro', { x: WC, apex: H * 0.17, size: 1.75 }); });
    T(281.0, function () { caption('またね。mata ne — see you again.', 'pawfav · end of the show'); });
    T(285.0, function () { endShow(); });

    ev.sort(function (a, b) { return a.t - b.t; });
    return ev;
  }

  function jumpToFinale() {
    if (!director) { pendingFinale = true; toast('the storm is being summoned…', 2.4); return; }
    director.events = director.events.filter(function (e) { return e.t >= 224; });
    director.events.unshift({ t: 224.2, fn: function () { actCard('終幕', 'PAWSTORM', 'no more waiting.'); } });
    director.events.unshift({ t: 224.2, fn: function () { setAct(actNames[4][0], actNames[4][1]); } });
    director.time = 224.0;
    director.idx = 0;
    toast('skipping to the storm…', 2.2);
  }

  /* ================= 6 · ambience modes ================= */
  var ambientTimer = null;
  function ambientTick(t) {
    if (!ambientTimer || t >= ambientTimer) {
      if (mode === 'free') {
        launchShell({ xPx: rnd(0.28, 0.72) * W, type: pick(['pistil', 'peony', 'chrys', 'saturn', 'kiku', 'ring', 'crossette']), apex: rnd(0.1, 0.3) * H, size: rnd(0.85, 1.3) });
        ambientTimer = t + rnd(3400, 5600);
      } else if (mode === 'zen') {
        var premium = ['kamuro', 'brocade', 'pistil', 'sakura', 'chrys', 'ring', 'kiku', 'saturn'];
        if (Math.random() < 0.13) {
          var x1 = rnd(0.14, 0.3) * W, x2 = rnd(0.7, 0.86) * W, apex = rnd(0.14, 0.26) * H;
          launchShell({ xPx: x1, type: pick(premium), apex: apex, size: rnd(0.95, 1.35) });
          launchShell({ xPx: x2, type: pick(premium), apex: apex, size: rnd(0.95, 1.35) });
        } else {
          launchShell({ xPx: rnd(0.3, 0.7) * W, type: pick(premium), apex: rnd(0.09, 0.28) * H, size: rnd(0.9, 1.55) });
        }
        ambientTimer = t + rnd(1250, 2350);
      }
    }
  }

  function startExperience(kind) {
    mode = kind;
    if (elIntro) elIntro.classList.add('gone');
    if (elEnd) elEnd.classList.remove('on');
    d.body.classList.add('pf-live');
    if (kind === 'show') {
      director = { time: 0, events: buildShow(), idx: 0 };
      if (pendingFinale) { pendingFinale = false; jumpToFinale(); }
      else toast('sound on — the river is listening', 2.6);
    } else if (kind === 'zen') {
      d.body.classList.add('pf-zen');
      ambientTimer = 0;
      toast('zen — the sky, unscripted. esc to come back', 4.2);
    } else {
      ambientTimer = 600;
      toast('tap anywhere in the sky to launch', 3.2);
    }
    updateShellHud();
  }
  function endShow() {
    mode = 'end';
    d.body.classList.remove('pf-live');
    store.set('pf-fav-shells', String(lifetime));
    var tonight = $('#pfEndTonight'), life = $('#pfEndLifetime');
    if (tonight) tonight.textContent = String(sessionShells);
    if (life) life.textContent = String(lifetime);
    if (elEnd) elEnd.classList.add('on');
  }
  function exitZen() {
    if (mode !== 'zen') return;
    d.body.classList.remove('pf-zen');
    d.body.classList.add('pf-live');
    mode = 'free';
    ambientTimer = performance.now() + 900;
    toast('welcome back', 1.8);
  }

  /* ================= 7 · icons & UI wiring ================= */
  var ICON = {
    muteOn: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6.5 9H3v6h3.5L11 19V5z" fill="currentColor" stroke="none" opacity=".9"/><path d="M15.5 9.2a4 4 0 0 1 0 5.6M18.4 6.4a8 8 0 0 1 0 11.2"/></svg>',
    muteOff: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6.5 9H3v6h3.5L11 19V5z" fill="currentColor" stroke="none" opacity=".9"/><path d="M16 9.5l5 5M21 9.5l-5 5"/></svg>',
    paw: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><ellipse cx="12" cy="15.6" rx="4.9" ry="4"/><ellipse cx="5.8" cy="10.6" rx="1.95" ry="2.45"/><ellipse cx="9.6" cy="7.2" rx="1.9" ry="2.4"/><ellipse cx="14.4" cy="7.2" rx="1.9" ry="2.4"/><ellipse cx="18.2" cy="10.6" rx="1.95" ry="2.45"/></svg>'
  };

  function updateShellHud() {
    if (elShells) elShells.textContent = String(sessionShells);
    var tot = $('#pfTotalLifetime');
    if (tot) tot.textContent = '✦ ' + (lifetime || 0).toLocaleString() + ' shells launched on this river (this device)';
  }

  /* begin / free / zen buttons (intro + live bar) */
  var beginBtn = $('#pfBegin');
  var freeBtn = $('#pfFree'), zenBtn = $('#pfZen'), freeBtn2 = $('#pfFreeLive'), zenBtn2 = $('#pfZenLive');
  var loadingSfx = false;

  function ensureSfx(next) {
    if (sfxReady || loadingSfx) { if (!loadingSfx) next(); return; }
    loadingSfx = true;
    var original = beginBtn ? beginBtn.innerHTML : '';
    var setLabel = function (txt) { if (beginBtn) beginBtn.innerHTML = txt; };
    setLabel('loading the night…');
    if (beginBtn) beginBtn.classList.add('loading');
    decodeAll(function (doneCount, total) {
      setLabel('loading the night · ' + doneCount + ' / ' + total);
    }, function () {
      loadingSfx = false;
      if (beginBtn) { beginBtn.classList.remove('loading'); beginBtn.innerHTML = original; }
      if (!sfxReady && sfxFailed.length) toast('samples blocked — synthesizer fireworks online', 3);
      next();
    });
  }

  if (beginBtn) beginBtn.addEventListener('click', function () { ensureSfx(function () { startExperience('show'); }); });
  if (freeBtn) freeBtn.addEventListener('click', function () { ensureSfx(function () { startExperience('free'); }); });
  if (zenBtn) zenBtn.addEventListener('click', function () { ensureSfx(function () { startExperience('zen'); }); });
  if (freeBtn2) freeBtn2.addEventListener('click', function () { startExperience('free'); });
  if (zenBtn2) zenBtn2.addEventListener('click', function () { startExperience('zen'); });
  if (elSkip) elSkip.addEventListener('click', jumpToFinale);

  /* mute + volume */
  $$('[data-pf-mute]').forEach(function (btn) {
    btn.innerHTML = muted ? ICON.muteOff : ICON.muteOn;
    btn.addEventListener('click', function () { setMuted(!muted); });
  });
  var vol = $('#pfVol');
  if (vol) {
    vol.value = String(Math.round(volume * 100));
    vol.addEventListener('input', function () { setVolume(parseInt(vol.value, 10) / 100); });
  }

  /* tap the sky to launch */
  function tapLaunch(clientX, clientY) {
    if (mode !== 'free' && mode !== 'zen' && mode !== 'show') return;
    if (mode === 'show') { /* let the show breathe — taps still paint the sky, small & quiet */
      launchShell({ xPx: clientX, type: pick(['pistil', 'peony', 'ring']), apex: clamp(clientY, H * 0.06, H * 0.52), size: 0.75, silent: false });
      return;
    }
    launchShell({ xPx: clientX, type: pick(['pistil', 'peony', 'chrys', 'kiku', 'saturn', 'ring', 'crossette', 'sakura']), apex: clamp(clientY, H * 0.06, H * 0.52), size: rnd(0.9, 1.35) });
  }
  canvas.addEventListener('pointerdown', function (e) {
    tapLaunch(e.clientX, e.clientY);
  }, { passive: true });

  /* end-card buttons */
  var againBtn = $('#pfAgain'); if (againBtn) againBtn.addEventListener('click', function () { ensureSfx(function () { startExperience('show'); }); });
  var freeEnd = $('#pfFreeEnd'); if (freeEnd) freeEnd.addEventListener('click', function () { startExperience('free'); });
  var shareBtn = $('#pfShare');
  if (shareBtn) shareBtn.addEventListener('click', function () {
    try {
      var out = d.createElement('canvas');
      out.width = W; out.height = H;
      var octx = out.getContext('2d');
      octx.fillStyle = '#07050c'; octx.fillRect(0, 0, W, H);
      if (bgImg && bgImg.complete && bgImg.naturalWidth) {
        /* cover-fit draw of the bg image */
        var iw = bgImg.naturalWidth, ih = bgImg.naturalHeight;
        var sc = Math.max(W / iw, H / ih), dw = iw * sc, dh = ih * sc;
        octx.drawImage(bgImg, (W - dw) / 2, (H - dh) / 2, dw, dh);
      }
      octx.drawImage(canvas, 0, 0, W, H);
      /* caption strip */
      octx.fillStyle = 'rgba(7,5,12,.42)'; octx.fillRect(0, H - 84, W, 84);
      octx.fillStyle = '#ffd9e2'; octx.font = '600 26px Caveat, cursive'; octx.textAlign = 'center';
      octx.fillText('PAWFAV · 花火 — see you offline, under the fireworks', W / 2, H - 46);
      octx.fillStyle = '#8f8299'; octx.font = '11px sans-serif';
      octx.fillText('P A W G R A M', W / 2, H - 20);
      out.toBlob(function (blob) {
        if (!blob) return;
        var file = null;
        try { file = new File([blob], 'pawfav.png', { type: 'image/png' }); } catch (e) {}
        if (file && navigator.canShare && navigator.canShare({ files: [file] })) {
          navigator.share({ files: [file], title: 'PAWFAV · 花火', text: 'the fireworks night on PAWGRAM' }).catch(function () {});
        } else {
          var a = d.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'pawfav.png';
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
          toast('saved — post it anywhere 🎆', 3);
        }
      }, 'image/png');
    } catch (e) { toast('share not available here', 2.4); }
  });

  /* keyboard: konami + mochi + zen escape */
  var KONAMI = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];
  var konamiIdx = 0, mochiBuf = '';
  w.addEventListener('keydown', function (e) {
    var code = e.code;
    if (code === 'Escape') { exitZen(); return; }
    if (code === 'KeyZ' && !e.metaKey && !e.ctrlKey && !e.altKey) { /* don't steal typing toggles */
      if (mode === 'zen') exitZen();
      return;
    }
    if (KONAMI[konamiIdx] === code) {
      konamiIdx++;
      if (konamiIdx === KONAMI.length) { konamiIdx = 0; mochiTorrent(); }
    } else konamiIdx = (KONAMI[0] === code) ? 1 : 0;
    if (code && code.indexOf('Key') === 0 && code.length === 4) {
      mochiBuf = (mochiBuf + code.charAt(3).toLowerCase()).slice(-5);
      if (mochiBuf === 'mochi') { mochiBuf = ''; mochiVolley(); }
    }
  });
  function mochiVolley() {
    if (mode === 'intro') return;
    for (var i = 0; i < 4; i++) {
      setTimeout(function () {
        launchShell({ xPx: rnd(0.2, 0.4) * W, type: 'paw', apex: rnd(0.1, 0.28) * H, size: rnd(0.9, 1.25) });
        launchShell({ xPx: rnd(0.6, 0.8) * W, type: 'paw', apex: rnd(0.1, 0.28) * H, size: rnd(0.9, 1.25) });
      }, i * 420);
    }
    toast('mochi inspected the fireworks. he approves. 🐾', 3.6);
  }
  function mochiTorrent() {
    if (mode === 'intro') return;
    toast('MOCHI TORRENT 🐾 — hold onto your lanterns', 3.4);
    var i = 0;
    var storm = setInterval(function () {
      i++;
      launchShell({ xPx: rnd(0.1, 0.9) * W, type: pick(['paw', 'heart', 'kamuro', 'brocade']), apex: rnd(0.08, 0.3) * H, size: rnd(1.1, 1.9) });
      if (i === 6) playSample('crowd-roar', { delay: 0.2, pan: 0, vol: 1.0 });
      if (i === 8) playSample('crowd-applause', { delay: 0.4, pan: 0, vol: 0.9 });
      if (i >= 16) clearInterval(storm);
    }, 230);
    flashA = Math.max(flashA, 0.3);
  }

  /* mobile: double-tap top-right exits zen */
  var lastCornerTap = 0;
  w.addEventListener('pointerdown', function (e) {
    if (mode !== 'zen') return;
    if (e.clientX > W - 96 && e.clientY < 96) {
      var t = performance.now();
      if (t - lastCornerTap < 420) exitZen();
      lastCornerTap = t;
    }
  }, { passive: true });

  /* background parallax (skip when reduced motion / touch) */
  var bgTX = 0, bgTY = 0, bgCX = 0, bgCY = 0;
  if (!reduce && !('ontouchstart' in w)) {
    w.addEventListener('pointermove', function (e) {
      bgTX = ((e.clientX / W) - 0.5) * -16;
      bgTY = ((e.clientY / H) - 0.5) * -10;
    }, { passive: true });
  }

  /* ================= 8 · main loop, resize, visibility ================= */
  var lastT = 0;
  function frame(t) {
    requestAnimationFrame(frame);
    if (!lastT) lastT = t;
    var dt = clamp((t - lastT) / 1000, 0, 0.05);
    lastT = t;
    step(dt);
    if (mode === 'show' && director) { director.time += dt; while (director.idx < director.events.length && director.events[director.idx].t <= director.time) { var ev = director.events[director.idx]; try { ev.fn(); } catch (e) {} director.idx++; } if (elSkip) elSkip.classList.toggle('show', director.idx < director.events.length); }
    else ambientTick(t);
    if (mode !== 'intro' && mode !== 'end') distantTick(t);
    draw();
    /* parallax lerp */
    if (bgImg && (bgTX || bgTY || bgCX || bgCY)) {
      bgCX = lerp(bgCX, bgTX, 0.045); bgCY = lerp(bgCY, bgTY, 0.045);
      bgImg.style.transform = 'translate3d(' + bgCX.toFixed(2) + 'px,' + bgCY.toFixed(2) + 'px,0)';
    }
    /* shake */
    if (shakeMag > 0.25) {
      canvas.style.transform = 'translate3d(' + ((Math.random() - 0.5) * 2 * shakeMag).toFixed(1) + 'px,' + ((Math.random() - 0.5) * 2 * shakeMag).toFixed(1) + 'px,0)';
    } else if (canvas.style.transform) canvas.style.transform = '';
  }

  var resizeT = null;
  w.addEventListener('resize', function () {
    clearTimeout(resizeT);
    resizeT = setTimeout(sizeCanvas, 130);
  });
  d.addEventListener('visibilitychange', function () {
    if (d.hidden) { if (actx) actx.suspend().catch(function () {}); lastT = 0; }
    else if (actx) actx.resume().catch(function () {});
  });

  /* ================= 9 · boot ================= */
  sizeCanvas();
  requestAnimationFrame(frame);
  updateShellHud();
  $$('[data-yr]').forEach(function (el) { el.textContent = String(new Date().getFullYear()); });
})(window, document);
