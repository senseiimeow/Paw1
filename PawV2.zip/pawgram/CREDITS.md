# PAWGRAM — asset credits

## PawFav · 花火 (pawfav.html)
- **Background artwork** (`art/pawfav-bg.jpg`): original AI-generated illustration created for
  this project (characters reference the official Tejas & Pragati character sheets).
- **Fireworks / crowd sounds** (`art/sfx/*.mp3`): free sound effects from
  [Mixkit](https://mixkit.co/free-sound-effects/), used under the
  [Mixkit License](https://mixkit.co/license/#sfxFree) (free for commercial & personal projects,
  no attribution required — credited here anyway):
  - Fireworks: `whistle` `whistle-pop` `whoosh` `crackle` `echo`
  - Explosions: `boom-s` `boom-m` `boom-double` `boom-deep` `boom-l` `boom-xl`
  - Crowd: `crowd-ooh` `crowd-roar` `crowd-applause`
- **Fireworks engine**: original vanilla-JS canvas engine (no libraries).
- Synthesised WebAudio fallbacks used automatically if samples cannot be decoded.
