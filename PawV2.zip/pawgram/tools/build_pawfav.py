#!/usr/bin/env python3
"""
PAWFAV build — inlines assets/css/pg-pawfav.css + assets/js/pg-pawfav.js
into the self-contained pawfav.html (same convention as the rest of the site).

    python3 tools/build_pawfav.py
"""
import pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
CSS = (ROOT / 'assets/css/pg-pawfav.css').read_text(encoding='utf-8')
JS  = (ROOT / 'assets/js/pg-pawfav.js').read_text(encoding='utf-8')

HTML = """<!DOCTYPE html>
<html lang="en" data-theme="night">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>PAWFAV · 花火 — the festival night — PAWGRAM</title>
<meta name="description" content="A see you offline special scene: Tejas and Pragati watch the summer fireworks over the Sumida river. A full-screen hanabi finale with real gunpowder, a scripted 4¾-minute show and an endless Zen sky.">
<meta name="theme-color" content="#07050c">
<meta name="color-scheme" content="dark">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="PAWFAV">

<!-- Open Graph / Twitter -->
<meta property="og:type" content="website">
<meta property="og:site_name" content="PAWGRAM — See You Offline">
<meta property="og:title" content="PAWFAV · 花火 — the festival night">
<meta property="og:description" content="Tejas and Pragati, one blanket, one river, four and a half minutes of light. A see you offline special scene.">
<meta property="og:image" content="https://pawgram.vercel.app/art/pawfav-bg.jpg">
<meta property="og:url" content="https://pawgram.vercel.app/pawfav.html">
<meta property="og:image:width" content="1376">
<meta property="og:image:height" content="768">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="PAWFAV · 花火 — the festival night">
<meta name="twitter:description" content="Tejas and Pragati, one blanket, one river, four and a half minutes of light.">
<meta name="twitter:image" content="https://pawgram.vercel.app/art/pawfav-bg.jpg">

<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="art/favicon-32.png" sizes="32x32">
<link rel="apple-touch-icon" href="art/apple-touch-icon.png">
<link rel="preload" href="art/pawfav-bg.jpg" as="image">
<link rel="preload" href="assets/fonts/bricolage-latin-var.woff2" as="font" type="font/woff2" crossorigin>

<style>
@font-face{font-family:"Bricolage";src:url("assets/fonts/bricolage-latin-var.woff2") format("woff2");font-weight:200 800;font-style:normal;font-display:swap;unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"Baloo";src:url("assets/fonts/baloo-latin-700.woff2") format("woff2");font-weight:700;font-style:normal;font-display:swap;unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"Caveat";src:url("assets/fonts/caveat-latin-700.woff2") format("woff2");font-weight:700;font-style:normal;font-display:swap}
/*__PAWFAV_CSS__*/
</style>
</head>
<body class="pawfav">
<a class="skip" href="#pfBegin" style="position:fixed;left:12px;top:-80px;z-index:99;background:var(--c-coral);color:#1a0d10;padding:12px 18px;border-radius:999px;font-size:12px;font-weight:700;transition:top .3s">Skip to the show</a>

<main class="pf-stage" id="pfMain" aria-label="PawFav — interactive fireworks finale">
  <img id="pfBg" class="pf-bg" src="art/pawfav-bg.jpg" alt="Tejas and Pragati seen from behind on a picnic blanket at the Sumida river fireworks festival — yatai stalls, paper lanterns, the Skytree glowing on the horizon" fetchpriority="high">
  <canvas id="pfFx" class="pf-fx" role="application" aria-label="Interactive fireworks — tap or click anywhere in the sky to launch a shell"></canvas>
  <div class="pf-grade" aria-hidden="true"></div>
  <div class="pf-lantern-glow lg-left" aria-hidden="true"></div>
  <div class="pf-lantern-glow lg-right" aria-hidden="true"></div>
  <div class="pf-zen-hint" aria-hidden="true">esc · double-tap corner · to return</div>

  <!-- ══ topbar ══ -->
  <header class="pf-top">
    <a class="pf-brand" href="index.html" aria-label="PawFav — back to PAWGRAM home">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <defs><linearGradient id="pfn1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#ff5f7e"/><stop offset=".5" stop-color="#ffd166"/><stop offset="1" stop-color="#ffb7c5"/>
        </linearGradient></defs>
        <ellipse cx="12" cy="15.4" rx="5.1" ry="4.1" fill="url(#pfn1)"/>
        <ellipse cx="5.6" cy="10.2" rx="2.05" ry="2.6" fill="url(#pfn1)"/>
        <ellipse cx="9.7" cy="6.6" rx="2" ry="2.55" fill="url(#pfn1)"/>
        <ellipse cx="14.6" cy="6.6" rx="2" ry="2.55" fill="url(#pfn1)"/>
        <ellipse cx="18.5" cy="10.2" rx="2.05" ry="2.6" fill="url(#pfn1)"/>
      </svg>
      <span><span class="w1">PAW<b>FAV</b></span><span class="w2">花火 — hanabi</span></span>
    </a>
    <div class="pf-topright">
      <button class="pf-iconbtn" data-pf-mute type="button" aria-pressed="false" aria-label="Mute fireworks sounds" title="Sound on / off"></button>
      <a class="pf-iconbtn pf-close" href="index.html" aria-label="Back to PAWGRAM home">← home</a>
    </div>
  </header>

  <!-- ══ INTRO ══ -->
  <section class="pf-intro" id="pfIntro" aria-label="PawFav — the fireworks finale">
    <div class="pf-kanji-mark" aria-hidden="true">花火</div>
    <div class="pf-intro-in">
      <span class="pf-chip"><i></i> Pawgram · Special Scene</span>
      <h1 class="pf-title">PAW<span class="paw">FAV</span></h1>
      <p class="pf-sub">花火 — hanabi · the festival night</p>
      <p class="pf-line">Seven months in the thread. One night under the lanterns. Stay for Tejas and Pragati’s
      summer show over the Sumida river — <b>real gunpowder, one blanket, and a sky that refuses to hold its breath.</b></p>
      <div class="pf-cta-row">
        <button class="btn pf-begin" id="pfBegin" type="button"><svg viewBox="0 0 24 24" width="17" height="17" fill="currentColor" aria-hidden="true"><path d="M8.2 5.6v12.8c0 1.25 1.36 2 2.4 1.34l10.2-6.4a1.58 1.58 0 0 0 0-2.68L10.6 4.26c-1.05-.66-2.4.09-2.4 1.34Z"/></svg>&ensp;Begin the show</button>
        <button class="btn ghost" id="pfFree" type="button"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 2.2c.62 5 2.4 7.7 8.9 8.3-6.5.62-8.28 3.3-8.9 8.3-.62-5-2.4-7.68-8.9-8.3 6.5-.6 8.28-3.3 8.9-8.3Z"/></svg>&ensp;Free play</button>
        <button class="btn lav" id="pfZen" type="button"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" aria-hidden="true"><path d="M19.6 8.6A8.6 8.6 0 1 0 20.4 13"/></svg>&ensp;Zen</button>
      </div>
      <p class="pf-note"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="2" y="14" width="5" height="6" rx="2"/><rect x="17" y="14" width="5" height="6" rx="2"/></svg> best with sound on · headphones recommended</p>
      <p class="pf-total" id="pfTotalLifetime"></p>
    </div>
  </section>

  <!-- ══ LIVE HUD ══ -->
  <button class="pf-pillbtn pf-skip" id="pfSkip" type="button">skip to the storm ›</button>
  <div class="pf-controls" aria-label="Show controls">
    <div class="pf-actchip"><span class="a-jp" id="pfActJp">第一幕</span><span class="a-en" id="pfActEn">first spark</span></div>
    <div class="pf-mid">
      <div class="pf-volwrap" title="Volume">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#cfc0d4" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M11 5 6.5 9H3v6h3.5L11 19V5z" fill="#cfc0d4" stroke="none"/><path d="M15.5 9.2a4 4 0 0 1 0 5.6"/></svg>
        <input type="range" id="pfVol" min="0" max="100" value="90" aria-label="Volume">
      </div>
      <button class="pf-pillbtn" id="pfZenLive" type="button" title="Hide everything — an endless, unscripted sky"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" aria-hidden="true"><path d="M19.6 8.6A8.6 8.6 0 1 0 20.4 13"/></svg>&thinsp;Zen</button>
      <button class="pf-pillbtn warm" id="pfFreeLive" type="button" title="Leave the choreography — launch freely"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 2.2c.62 5 2.4 7.7 8.9 8.3-6.5.62-8.28 3.3-8.9 8.3-.62-5-2.4-7.68-8.9-8.3 6.5-.6 8.28-3.3 8.9-8.3Z"/></svg>&thinsp;Free</button>
    </div>
    <div class="pf-shells"><span class="s-n" id="pfShellCount">0</span><span class="s-l">shells tonight</span></div>
  </div>
  <p class="pf-kbd" aria-hidden="true">↑↑↓↓←→←→ B A · there is a storm back there</p>

  <!-- ══ captions · act cards · toast ══ -->
  <div class="pf-caption" id="pfCaption" aria-live="polite"><span id="pfCaptionText"></span><small id="pfCaptionSub"></small></div>
  <div class="pf-act" id="pfActCard" aria-hidden="true">
    <div class="pf-act-in">
      <div class="pf-act-jp" id="pfActCardJp">第一幕</div>
      <div class="pf-act-en" id="pfActCardEn">FIRST SPARK</div>
      <div class="pf-act-line" id="pfActCardLine"></div>
    </div>
  </div>
  <div class="pf-toast" id="pfToast" role="status" aria-live="polite"></div>

  <!-- ══ END CARD ══ -->
  <div class="pf-end" id="pfEnd" role="dialog" aria-modal="true" aria-label="End of the show">
    <div class="pf-end-card">
      <div class="pf-end-jp">またね、花火</div>
      <div class="pf-end-en">see you again, fireworks</div>
      <p class="pf-end-line">The last chrysanthemum slid into the river, ten thousand people exhaled at once, and
      somewhere in the dark two people pretended they weren’t crying. This is the night the name makes sense.</p>
      <div class="pf-end-stats">
        <div><b id="pfEndTonight">0</b><span>shells tonight</span></div>
        <div><b id="pfEndLifetime">0</b><span>total on device</span></div>
        <div><b>4</b><span>acts</span></div>
      </div>
      <div class="pf-end-btns">
        <button class="btn" id="pfAgain" type="button">もう一度 · Again</button>
        <button class="btn ghost" id="pfFreeEnd" type="button"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12 2.2c.62 5 2.4 7.7 8.9 8.3-6.5.62-8.28 3.3-8.9 8.3-.62-5-2.4-7.68-8.9-8.3 6.5-.6 8.28-3.3 8.9-8.3Z"/></svg>&ensp;Free play</button>
        <a class="btn ghost" href="index.html">←&ensp;home</a>
      </div>
      <div class="pf-end-btns" style="margin-top:12px">
        <button class="pf-pillbtn warm" id="pfShare" type="button"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7M9.5 7H17v7.5"/></svg>&ensp;Share this night</button>
      </div>
      <p class="pf-share-note">canvas → png · nothing leaves this device unless you press it</p>
    </div>
  </div>
</main>

<script>
/*__PAWFAV_JS__*/
</script>
</body>
</html>
"""

html = HTML.replace('/*__PAWFAV_CSS__*/', CSS).replace('/*__PAWFAV_JS__*/', JS)
assert '__PAWFAV_CSS__' not in html and '__PAWFAV_JS__' not in html
out = ROOT / 'pawfav.html'
out.write_text(html, encoding='utf-8')
print('wrote', out, len(html) // 1024, 'KB')
